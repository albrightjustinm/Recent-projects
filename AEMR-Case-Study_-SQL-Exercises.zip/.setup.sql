DROP DATABASE IF EXISTS springboard;
CREATE DATABASE springboard;
USE springboard;

CREATE TABLE AEMR (
    Start_Time DATETIME,
    End_Time DATETIME, 
    Facility_Code VARCHAR(1024),
    Participant_Code VARCHAR(1024),
    Status VARCHAR(1024),
    Reason VARCHAR(1024),
    Outage_MW FLOAT,
    Recovery_Time_Minutes INTEGER,
    Description VARCHAR(1024)
);

LOAD DATA LOCAL INFILE '/home/nt-user/workspace/.data.csv' 
INTO TABLE AEMR 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
