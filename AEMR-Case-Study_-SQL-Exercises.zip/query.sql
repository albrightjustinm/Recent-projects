select
Participant_Code,
max(Facility_Code) AS 'Facility_Code', 
Status,
Year(Start_Time) AS 'Year', 
round(avg(Outage_MW),2) AS 'Avg_Outage_MW_Loss',
round(sum(Outage_MW),2) AS Summed_Energy_Lost
from AEMR
where Status = 'Approved' and Reason = 'Forced'
group by Participant_Code, Status, Year
order by Year, Summed_Energy_Lost desc






















